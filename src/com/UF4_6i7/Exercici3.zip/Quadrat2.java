package com.UF4_6i7;

public class Quadrat2 extends Rectangle2 {
	
	/*
	  Genera una classe Quadrat, que hereti de la classe Rectangle, on hi hagi una sobreescriptura del m�tode TipusRectangle per que mostri 
	  per pantalla el literal �S� al 100% que s�c un quadrat�.
	 */
	
	@Override
	public void tipusRectangle() {
		System.out.println("S� al 100% que s�c un quadrat");
	}
}
