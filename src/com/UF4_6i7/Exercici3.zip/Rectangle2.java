package com.UF4_6i7;

public class Rectangle2 extends Figura2 {
	
	//  L��rea del rectangle �s base per altura
	
	
	public int calcularArea(int amplada, int altura) {
		return amplada * altura;
	} 
	
	/*
	 Genera un m�tode a la classe Rectangle anomenat TipusRectangle, que no tingui par�metres d�entrada ni de sortida ni retorni cap valor, 
	 que mostri per pantalla el literal �No s� si s�c un quadrat�.
	 */
	public void tipusRectangle() {
		System.out.println("No s� si s�c un quadrat");
	}
}
