package com.UF4_7;

public class Figura3 {
	
	private int amplada;
	private int altura;
	
	//METHODS:
	public int calcularArea(int amplada, int altura) {
		System.out.println("No s�c una figura definida, pel que no s� calcular l��rea. Retornar� 0");
		return 0;
	}

	public int getAmplada() {
		return amplada;
	}

	public void setAmplada(int amplada) {
		this.amplada = amplada;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}
	
}
