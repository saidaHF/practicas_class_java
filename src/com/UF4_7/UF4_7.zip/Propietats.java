package com.UF4_7;

// f. Genereu una interf�cie anomenada Propietats que defineixi dos m�todes nous: 
//    mostraCostats i mostraVertex. Els dos m�todes no tindran par�metres d'entrada ni retornaran cap valor.


public interface Propietats {
	
	public void mostraCostats();
	public void mostraVertex();
}
