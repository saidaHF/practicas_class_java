package com.UF4_examen;

public interface Porta {
	/*
	 Interf�cie Porta (1,5 punts)
		1. M�todes
			1. ObrirPorta (p�blic)
			2. TancarPorta (p�blic)
	 */
	
	public void obrirPorta();
	public void tancarPorta();
}
